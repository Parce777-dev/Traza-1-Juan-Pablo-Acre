package entidades;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString(exclude = "sucursales")
@SuperBuilder
public class Empresa {
    private Long id;
    private String nombre;
    private String razonSocial;
    private Long cuit;

    @Builder.Default
    private Set<Sucursal> sucursales = new HashSet<>();
    public void agregarSucursal(Sucursal sucursal) {
        sucursales.add(sucursal);
    }
    public Set<Sucursal> obtenerSucursales() {
        return Collections.unmodifiableSet(sucursales);
    }
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Empresa{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", razonSocial='" + razonSocial + '\'' +
                ", cuit=" + cuit +
                '}';
    }

}
