import entidades.*;
import repositorios.InMemoryRepository;

import java.time.LocalTime;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Usamos directamente el repositorio genérico
        InMemoryRepository<Empresa> empresaRepo = new InMemoryRepository<>();

        // Crear país Argentina
        Pais argentina = Pais.builder().id(1L).nombre("Argentina").build();

        // Provincias
        Provincia buenosAires = Provincia.builder().id(2L).nombre("Buenos Aires").pais(argentina).build();
        Provincia cordoba = Provincia.builder().id(3L).nombre("Mendoza").pais(argentina).build();

        // Localidades
        Localidad caba = Localidad.builder().id(4L).nombre("CABA").provincia(buenosAires).build();
        Localidad laPlata = Localidad.builder().id(5L).nombre("La Plata").provincia(buenosAires).build();
        Localidad mendoza = Localidad.builder().id(6L).nombre("Mendoza").provincia(cordoba).build();
        Localidad maipu = Localidad.builder().id(7L).nombre("Maipú").provincia(cordoba).build();

        // Domicilios
        Domicilio domicilioCaba = new Domicilio(1L, "San Martin", 1234, 1000, 3, 5,  caba);
        Domicilio domicilioLaPlata = new Domicilio(2L, "44", 456, 1900, 4, 3, laPlata);
        Domicilio domicilioMendoza = new Domicilio(3L, "España", 789, 5000, 1, 1, mendoza);
        Domicilio domicilioMaipu = new Domicilio(4L, "20 de junio", 321, 5152, 2, 2, maipu);

        // Sucursales
        Sucursal sucursal1 = Sucursal.builder()
                .id(1L)
                .nombre("Clases.Sucursal CABA")
                .domicilio(domicilioCaba)
                .horarioApertura(LocalTime.of(9, 0))
                .horarioCierre(LocalTime.of(18, 0))
                .esCasaMatriz(true)
                .build();

        Sucursal sucursal2 = Sucursal.builder()
                .id(2L)
                .nombre("Clases.Sucursal La Plata")
                .domicilio(domicilioLaPlata)
                .horarioApertura(LocalTime.of(9, 0))
                .horarioCierre(LocalTime.of(17, 0))
                .esCasaMatriz(false)
                .build();

        Sucursal sucursal3 = Sucursal.builder()
                .id(3L)
                .nombre("Clases.Sucursal Mendoza")
                .domicilio(domicilioMendoza)
                .horarioApertura(LocalTime.of(8, 30))
                .horarioCierre(LocalTime.of(17, 30))
                .esCasaMatriz(true)
                .build();

        Sucursal sucursal4 = Sucursal.builder()
                .id(4L)
                .nombre("Clases.Sucursal Maipu")
                .domicilio(domicilioMaipu)
                .horarioApertura(LocalTime.of(10, 0))
                .horarioCierre(LocalTime.of(18, 0))
                .esCasaMatriz(false)
                .build();

        // Empresas
        Empresa empresa1 = Empresa.builder()
                .nombre("Clases.Empresa Uno")
                .razonSocial("Clases.Empresa Uno S.A.")
                .cuit(12345678L)
                .build();
        empresa1.agregarSucursal(sucursal1);
        empresa1.agregarSucursal(sucursal2);

        Empresa empresa2 = Empresa.builder()
                .nombre("Clases.Empresa Dos")
                .razonSocial("Clases.Empresa Dos S.A.")
                .cuit(90123456L)
                .build();
        empresa2.agregarSucursal(sucursal3);
        empresa2.agregarSucursal(sucursal4);

        // Guardar empresas en el repositorio
        empresaRepo.save(empresa1);
        empresaRepo.save(empresa2);

        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // a) Mostrar todas las empresas
        System.out.println("Todas las empresas:");
        empresaRepo.findAll().forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // b) Buscar empresa por ID
        System.out.println("\nBuscar empresa por ID:");
        Empresa buscadaPorId = empresaRepo.findById(empresa1.getId()).orElse(null);
        System.out.println(buscadaPorId);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // c) Buscar empresa por nombre
        System.out.println("\nBuscar empresa por nombre:");
        List<Empresa> buscadasPorNombre = empresaRepo.genericFindByField("nombre", "Clases.Empresa Dos");
        buscadasPorNombre.forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // d) Actualizar CUIL de Clases.Empresa Uno
        System.out.println("\nActualizar CUIT:");
        empresa1.setCuit(23456789L);
        empresaRepo.genericUpdate(empresa1.getId(), empresa1);
        System.out.println(empresaRepo.findById(empresa1.getId()).orElse(null));
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        // e) Eliminar Clases.Empresa Dos
        System.out.println("\nEliminar Clases.Empresa Dos:");
        empresaRepo.genericDelete(empresa2.getId());
        empresaRepo.findAll().forEach(System.out::println);
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
    }
}